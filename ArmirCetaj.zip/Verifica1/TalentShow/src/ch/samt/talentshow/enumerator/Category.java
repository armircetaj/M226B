package ch.samt.talentshow.enumerator;

public enum Category {
    SINGER,
    DANCER,
    MAGICIAN
}
