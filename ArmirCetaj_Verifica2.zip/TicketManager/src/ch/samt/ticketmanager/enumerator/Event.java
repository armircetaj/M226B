package ch.samt.ticketmanager.enumerator;

public enum Event {
    CONCERT,
    THEATER,
    SPORT
}
