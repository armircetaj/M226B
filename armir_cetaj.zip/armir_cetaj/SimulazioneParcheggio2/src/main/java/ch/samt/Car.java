package ch.samt;

public class Car {
    private String name;

    public Car(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }
}
